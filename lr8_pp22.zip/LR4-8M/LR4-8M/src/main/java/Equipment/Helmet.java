package Equipment;

public class Helmet extends Armour {
    public Helmet() {
        this.setName("Ordinary helmet");
        this.setType("Helmet");
        this.setWeight(1.8);
        this.setPrice(170);
    }

    public Helmet(String name, String type, double weight, int price) {
        super(name, type, weight, price);
    }
}