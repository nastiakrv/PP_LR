package Equipment;

public class Breastplate extends Armour {
    public Breastplate() {
        this.setName("Ordinary breastplate");
        this.setType("Breastplate");
        this.setWeight(5.5);
        this.setPrice(250);
    }

    public Breastplate(String name, String type, double weight, int price) {
        super(name, type, weight, price);
    }
}
