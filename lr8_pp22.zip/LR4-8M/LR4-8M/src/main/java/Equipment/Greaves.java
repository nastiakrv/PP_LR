package Equipment;

public class Greaves extends Armour {
    public Greaves() {
        this.setName("Ordinary greaves");
        this.setType("Greaves");
        this.setWeight(7.4);
        this.setPrice(300);
    }

    public Greaves(String name, String type, double weight, int price) {
        super(name, type, weight, price);
    }
}