package Equipment;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

import static Menu.Menu.printArmourList;
import static Menu.Menu.getArmor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Armour {

    protected String name;
    protected String type;
    protected double weight;
    protected int price;
    private static final Logger logger = LogManager.getLogger();


    public Armour(){}

    @Override
    public String  toString() {
        return  "name: " + name + '\n' +
                "type: " + type + '\n' +
                "weight: " + weight +'\n' +
                "price: " + price + '\n';
    }

    public Armour(String name, String type, double weight, int price) {
        this.name = name;
        this.type = type;
        this.weight = weight;
        this.price = price;
    }

    public void sort_by_price(LinkedList<Armour> arm) throws IOException {
    try {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the lower limit of the price range: ");
        int low = scan.nextInt();
        System.out.println("Enter the upper limit of the price range: ");
        int upp = scan.nextInt();
        Collections.sort(arm, new Comparator<Armour>() {
            @Override
            public int compare(Armour arm1, Armour arm2) {
                return Double.compare(arm1.getPrice(), arm2.getPrice());
            }
        });
        LinkedList<Armour> sortedList = new LinkedList<>();
        for (Armour armour : arm) {
            if (armour.getPrice() >= low && armour.getPrice() <= upp) {
                sortedList.add(armour);
            }
        }
        System.out.println("\tSorted list:");
        printArmourList(sortedList);
        chosenArmour(sortedList);
    }catch (Exception e){
        logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
    }
    }

    public void sort_by_weight(LinkedList<Armour> listToSort/*, LinkedList<Armour> chosen*/) throws IOException {
        try {
            Scanner scan = new Scanner(System.in);
            System.out.println("\nChoose the way to sort elements:");
            System.out.println("1. Sort in ascending order");
            System.out.println("2. Sort in descending order");
            System.out.print("Your choice: ");
            int numb = scan.nextInt();
            while (numb != 1 && numb != 2) {
                System.out.println("You've entered incorrect number, try again");
                System.out.print("Your choice: ");
                numb = scan.nextInt();
            }
            switch (numb) {
                case 1:
                    Collections.sort(listToSort, new Comparator<Armour>() {
                        @Override
                        public int compare(Armour arm1, Armour arm2) {
                            return Double.compare(arm1.getWeight(), arm2.getWeight());
                        }
                    });
                    break;
                case 2:
                    Collections.sort(listToSort, new Comparator<Armour>() {
                        @Override
                        public int compare(Armour arm1, Armour arm2) {
                            return Double.compare(arm2.getWeight(), arm1.getWeight());
                        }
                    });
                    break;
            }
            System.out.println("\tSorted list:");
            printArmourList(listToSort);
            chosenArmour(listToSort);
        }catch (Exception e){
            logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
            logger.info("An unexpected error occurred.");
        }
    }
    public static void chosenArmour(LinkedList<Armour> sortedList) throws IOException {
        try{
        LinkedList<Armour> selectedArmour = new LinkedList<>();
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the number of element you want to choose:");
        int selectedNumb = scan.nextInt();
        if (selectedNumb >= 1 && selectedNumb <= sortedList.size()) {
            selectedArmour.add(sortedList.get(selectedNumb - 1));
            //System.out.println("Armour was added successfully");
        } else {
            System.out.println("Incorrect number of the element");
        }
        //printArmourList(selectedArmour);
        saveToFile(selectedArmour);}catch (Exception e){
            logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
        }
    }
    public static void saveToFile(LinkedList<Armour> armourList/*, String filename*/) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\Labs\\LR4-8\\SelectedArmour.txt", true))) {
            for (Armour arm : armourList) {
                writer.write( arm.getName() + ", " + arm.getType() + ", "
                        + arm.getWeight() + ", " + arm.getPrice() + "\n");
                System.out.println("Element was written to file successfuly");
            }
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void armourCatalog(){
        System.out.println("The catalog of all avialable armour");
        System.out.println("\n\t\tHelmets");
        LinkedList helmets = getArmor(1);
        printArmourList(helmets);
        System.out.println("\n\t\tBreastplates");
        LinkedList breastplates = getArmor(2);
        printArmourList(breastplates);
        System.out.println("\n\t\tGauntlets");
        LinkedList gauntlets = getArmor(3);
        printArmourList(gauntlets);
        System.out.println("\n\t\tGreaves");
        LinkedList greaves = getArmor(4);
        printArmourList(greaves);
        System.out.println("\n\t\tSabatons");
        LinkedList sabatons = getArmor(5);
        printArmourList(sabatons);
    }
    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getPrice() {
        return price;
    }
}



