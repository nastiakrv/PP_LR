package Equipment;

public class Gauntlets extends Armour {
    public Gauntlets() {
        this.setName("Ordinary gauntlets");
        this.setType("Gauntlets");
        this.setWeight(3.6);
        this.setPrice(200);
    }

    public Gauntlets(String name, String type, double weight, int price) {
        super(name, type, weight, price);
    }
}