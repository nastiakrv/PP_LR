package Equipment;

public class Sabatons extends Armour {
    public Sabatons() {
        this.setName("Ordinary sabatons");
        this.setType("Sabatons");
        this.setWeight(2.4);
        this.setPrice(190);
    }

    public Sabatons(String name, String type, double weight, int price) {
        super(name, type, weight, price);
    }
}