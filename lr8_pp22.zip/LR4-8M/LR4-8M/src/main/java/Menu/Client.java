package Menu;

import Equipment.Armour;
import java.io.IOException;

public class Client {
    public Client() {
    }

    public static void main(String[] args) throws IOException {
        Menu menu = new Menu();
        Armour armour = new Armour();
        Developer developer = new Developer(
                new SortByPrice(armour),
                new SortByWeight(armour),
                new ArmourCatalog(armour));
        menu.menu(developer);
    }
}