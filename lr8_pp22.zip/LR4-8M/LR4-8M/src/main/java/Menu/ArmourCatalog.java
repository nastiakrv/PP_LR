package Menu;

import Equipment.Armour;
import java.util.LinkedList;

public class ArmourCatalog implements Command {
    Armour armour;

    public ArmourCatalog(Armour arm) {
        this.armour = arm;
    }

    public void execute() {
        this.armour.armourCatalog();
    }

    public void executeArmour(LinkedList<Armour> armour) {
    }
}