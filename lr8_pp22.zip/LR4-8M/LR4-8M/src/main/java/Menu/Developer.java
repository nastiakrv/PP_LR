package Menu;

import Equipment.Armour;
import java.io.IOException;
import java.util.LinkedList;

public class Developer {
    Command sortByPrice;
    Command sortByWeight;
    Command armourCatalog;
    public Developer(){}

    public Developer(Command sortByPrice, Command sortByWeight, Command armourCatalog) {
        this.sortByPrice = sortByPrice;
        this.sortByWeight = sortByWeight;
        this.armourCatalog = armourCatalog;
    }

    public void sortByPriceRec(LinkedList<Armour> armour) throws IOException {
        this.sortByPrice.executeArmour(armour);
    }

    public void sortByWeightRec(LinkedList<Armour> armour) throws IOException {
        this.sortByWeight.executeArmour(armour);
    }

    public void armourCatalogRec() {
        this.armourCatalog.execute();
    }
}
