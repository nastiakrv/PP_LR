package Menu;

import Equipment.Armour;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Menu {

    private static final Logger logger = LogManager.getLogger();
    protected Scanner scan;

    public Menu() {
        this.scan = new Scanner(System.in);
    }

    public void menu(Developer developer) throws IOException {
        Menu menu = new Menu();
        try {
            int numb;
            do {
                System.out.println("\tMenu");
                System.out.println("Press 1 to equip your knight");
                System.out.println("Press 2 to see all the equipment available");
                System.out.println("Press 3 to exit");
                numb = this.scan.nextInt();
                switch (numb) {
                    case 1:
                        menu.chooseEquip(developer);
                        break;
                    case 2:
                        developer.armourCatalogRec();
                        break;
                    case 3:
                        System.out.println("You've exited");
                        this.deleteFile("SelectedArmour");
                }
            } while (numb != 3);
        }catch (Exception e){
            logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
        }
    }

    public void chooseEquip(Developer developer) throws IOException {
        Menu menu = new Menu();
        LinkedList armourList = new LinkedList();
        try{
        int numb;
        do {
            System.out.println("\n\tChoose the part of armour:");
            System.out.println("1. Helmet");
            System.out.println("2. Breastplate");
            System.out.println("3. Gauntlets");
            System.out.println("4. Greaves");
            System.out.println("5. Sabatons");
            System.out.println("6. Finish choosing and calculate the cost");
            System.out.print("Your choice: ");
            numb = this.scan.nextInt();
            if (numb == 6) {
                System.out.println("\n\tYour armour is ready:");
                LinkedList<Armour> selectedArmour = ListsFromFile("SelectedArmour", armourList);
                printArmourList(selectedArmour);
                int totalPrice = calculateCost(selectedArmour);
                System.out.println("Total price of chosen armour: " + totalPrice);
                break;
            }
            LinkedList armour = getArmor(numb);
            menu.sortMenu(developer, armour);
        } while(numb != 6);}catch (Exception e){
            logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
        }
    }

    private int calculateCost(LinkedList<Armour> selectedArmour) {
        int totalPrice = 0;
        for( Armour armorItem : selectedArmour){
            totalPrice += armorItem.getPrice();
        }
        return totalPrice;
    }

    public void sortMenu(Developer developer, LinkedList armour) throws IOException {
        try{
        System.out.println("\n\tChoose the way of sorting the elements:");
        System.out.println("1. Sorting by weight");
        System.out.println("2. Sorting by price range");
        System.out.print("Your choice: ");

        int choice;
        for(choice = this.scan.nextInt(); choice != 1 && choice != 2; choice = this.scan.nextInt()) {
            System.out.println("You've entered incorrect number, try again");
            System.out.print("Your choice: ");
        }

        switch (choice) {
            case 1:
                developer.sortByWeightRec(armour);
                break;
            case 2:
                developer.sortByPriceRec(armour);
        }}catch (Exception e){
            logger.fatal("An unexpected error occurred: {}", e.getMessage(), e);
        }
    }

    public static LinkedList getArmor(int numb) {
        LinkedList armor = new LinkedList();
        Menu Amunition = new Menu();
        switch (numb) {
            case 1:
                Amunition.ListsFromFile("Helmet", armor);
                break;
            case 2:
                Amunition.ListsFromFile("Breastplate", armor);
                break;
            case 3:
                Amunition.ListsFromFile("Gauntlets", armor);
                break;
            case 4:
                Amunition.ListsFromFile("Greaves", armor);
                break;
            case 5:
                Amunition.ListsFromFile("Sabatons", armor);
        }
        return armor;
    }

    public LinkedList ListsFromFile(String fileName, LinkedList armor) {
            try {
            BufferedReader br = new BufferedReader(new FileReader("D:\\Labs\\LR4-8\\" + fileName + ".txt"));

            String line;
            try {
                while((line = br.readLine()) != null) {
                    String[] parts = line.split(", ");
                    String name = parts[0];
                    String type = parts[1];
                    double weight = Double.parseDouble(parts[2]);
                    int price = Integer.parseInt(parts[3]);
                    Armour armorItem = new Armour(name, type, weight, price);
                    armor.add(armorItem);
                }
            } catch (Throwable var13) {
                try {
                    br.close();
                } catch (Throwable var12) {
                    var13.addSuppressed(var12);
                }

                throw var13;
            }

            br.close();
        } catch (IOException var14) {
            var14.printStackTrace();

        }
        return armor;
    }

    public static void printArmourList(LinkedList<Armour> armorList) {
        int i = 1;

        for(Iterator var2 = armorList.iterator(); var2.hasNext(); ++i) {
            Armour armorItem = (Armour)var2.next();
            System.out.println("" + i + ") " + String.valueOf(armorItem));
        }

    }

    public void deleteFile(String fileName) {
            File fileToDelete = new File("D:\\Labs\\LR4-8\\" + fileName + ".txt");
            if (fileToDelete.exists()) {
                fileToDelete.delete();
                System.out.println("File '" + fileName + ".txt' was deleted successfully");
            } else {
                System.out.println("File with the name '" + fileName + ".txt' doesn't exist");
            }
    }
}
