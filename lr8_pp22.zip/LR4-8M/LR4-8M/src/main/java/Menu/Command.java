package Menu;

import Equipment.Armour;
import java.io.IOException;
import java.util.LinkedList;

public interface Command {
    void execute();

    void executeArmour(LinkedList<Armour> var1) throws IOException;

//    void executeArmourW(LinkedList<Armour> var1, LinkedList<Armour> var2);
}