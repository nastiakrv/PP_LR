package Menu;

import Equipment.Armour;
import java.io.IOException;
import java.util.LinkedList;

public class SortByPrice implements Command {
    Armour armour;

    public SortByPrice(Armour arm) {
        this.armour = arm;
    }

    public void execute() {
    }

    public void executeArmour(LinkedList<Armour> arm) throws IOException {
        this.armour.sort_by_price(arm);
    }

//    public void executeArmourW(LinkedList<Armour> armour, LinkedList<Armour> armour1) {
//    }
}
