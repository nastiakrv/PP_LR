package Menu;

import Equipment.Armour;
import java.io.IOException;
import java.util.LinkedList;

public class SortByWeight implements Command {
    Armour armour;

    public SortByWeight(Armour arm) {
        this.armour = arm;
    }

    public void execute() {
    }

    public void executeArmour(LinkedList<Armour> arm) throws IOException {
        this.armour.sort_by_weight(arm);
    }

//    public void executeArmourW(LinkedList<Armour> armour, LinkedList<Armour> armour1) {
//    }
}