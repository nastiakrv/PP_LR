package Equipment;

import Menu.ArmourCatalog;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class ArmourTest {
    protected String name;
    protected String type;
    protected double weight;
    protected int price;

    @Test
    void getName() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        assertEquals("Magic helmet", armour.getName());
    }
    @Test
    void getType() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        assertEquals("helmet", armour.getType());
    }
    @Test
    void getWeight() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        assertEquals(2.02, armour.getWeight());
    }
    @Test
    void getPrice() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        assertEquals(400, armour.getPrice());
    }
    @Test
    void setName() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        armour.setName("Transparent helmet");
        //assertEquals("Magic helmet", armour.getName());
    }
    @Test
    void setType() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        armour.setType("helmet");
    }
    @Test
    void setWeight() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        armour.setWeight(2.02);
    }
    @Test
    void setPrice() {
        Armour armour = new Armour("Magic helmet", "helmet", 2.02, 400);
        armour.setPrice(400);
    }
    @Test
    void testToString() {
        Armour armour = new Armour();
        assertEquals("name: " + name + '\n' +
                "type: " + type + '\n' +
                "weight: " + weight +'\n' +
                "price: " + price + '\n', armour.toString());
    }

    @Test
    void sortByWeightTest() throws IOException {
        LinkedList armList = new LinkedList<>();
        Armour armour1 = new Armour("Magic helmet", "helmet", 8.02, 400);
        Armour armour2 = new Armour("Magic helmet", "helmet", 4.02, 400);
        armList.add(armour1);
        armList.add(armour2);
        Armour arm = new Armour();
        arm.sort_by_weight(armList);
    }
    @Test
    void sortByPriceTest() throws IOException {
        LinkedList armList = new LinkedList<>();
        Armour armour1 = new Armour("Magic helmet", "helmet", 8.02, 400);
        Armour armour2 = new Armour("Magic helmet", "helmet", 4.02, 400);
        armList.add(armour1);
        armList.add(armour2);
        Armour arm = new Armour();
        arm.sort_by_price(armList);
    }
    @Test
    void saveToFileTest1() {
        Armour menu = new Armour();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        LinkedList<Armour> armourList = new LinkedList<>();
        menu.saveToFile(armourList);
        String consoleOutput = outputStream.toString();
        assertTrue(consoleOutput.contains("Element was written to file successfully"));
        System.setOut(System.out);
    }

    @Test
    public void saveToFileTest() throws IOException {
        Armour menu = new Armour();
        // Створюємо об'єкт Armour та список для тесту
        Armour armour = new Armour("TestHelmet", "Helmet", 2.0, 100);
        LinkedList<Armour> armourList = new LinkedList<>();
        armourList.add(armour);
    }
    @Test
    public void armourCatalogTest(){
        LinkedList<Armour> arm = new LinkedList<>();
        //Armour arm = new Armour("TestHelmet", "Helmet", 2.0, 100);
        Armour armour = new Armour();
        ArmourCatalog command = new ArmourCatalog(armour);
        command.executeArmour(arm);
    }
}
