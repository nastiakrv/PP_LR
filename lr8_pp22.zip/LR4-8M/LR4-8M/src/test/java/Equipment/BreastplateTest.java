package Equipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BreastplateTest {
@Test
    void breastTest(){
    Breastplate breastplate = new Breastplate("Magic breastplate", "breastplate", 3.75, 375);
}
    @Test
    void breastTest1(){
        Breastplate breastplate = new Breastplate();
        breastplate.setName("Magic breastplate");
        breastplate.setType("breastplate");
        breastplate.setWeight(3.75);
        breastplate.setPrice(375);
    }

}