package Equipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GreavesTest {
    @Test
    void greavTest(){
        Greaves greaves = new Greaves("Magic greaves", "greaves", 3.75, 522);
    }
    @Test
    void greavTest1(){
        Greaves greaves = new Greaves();
        greaves.setName("Magic greaves");
        greaves.setType("greaves");
        greaves.setWeight(3.75);
        greaves.setPrice(522);
    }


}