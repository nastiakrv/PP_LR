package Equipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SabatonsTest {
    @Test
    void sabTest(){
        Sabatons sabatons = new Sabatons("Magic sabatons", "sabatons", 3.75, 522);
    }
    @Test
    void sabTest1(){
        Sabatons sabatons = new Sabatons();
        sabatons.setName("Magic helmet");
        sabatons.setType("helmet");
        sabatons.setWeight(3.75);
        sabatons.setPrice(522);
    }


}