package Equipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GauntletsTest {
    @Test
    void gauntTest(){ Gauntlets gauntlets = new Gauntlets("Magic gauntlets", "gauntlets", 3.75, 522);
    }
    @Test
    void gauntTest1(){
        Gauntlets gauntlets = new Gauntlets();
        gauntlets.setName("Magic gauntlets");
        gauntlets.setType("gauntlets");
        gauntlets.setWeight(3.75);
        gauntlets.setPrice(522);
    }

}