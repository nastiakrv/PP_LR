package Equipment;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HelmetTest {
    @Test
    void helmTest(){
        Helmet helmet = new Helmet("Magic helmet", "helmet", 3.75, 522);
    }
    @Test
    void helmTest1(){
        Helmet helmet = new Helmet();
        helmet.setName("Magic helmet");
        helmet.setType("helmet");
        helmet.setWeight(3.75);
        helmet.setPrice(522);
    }

}