package Menu;

import Equipment.Armour;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class DeveloperTest {
    @Test
    void executeTest(){
        Armour armour = new Armour();
        Developer developer = new Developer();

    }
    @Test
    void executeArmTest(){
        LinkedList<Armour> armList = new LinkedList();
        Armour armour = new Armour();
        ArmourCatalog armourCatalog = new ArmourCatalog(armour);
        armourCatalog.executeArmour(armList);
    }
    @Test
    void sortByPriceRecTest() {
        Armour armour = new Armour();
        // Створюємо реальний об'єкт розробника з реальними командами
        Developer developer = new Developer(new SortByWeight(armour), new ArmourCatalog(armour), new SortByPrice(armour));

        // Створюємо список обладунків
        LinkedList<Armour> armourList = new LinkedList<>();
        // Додаємо елементи до списку

        // Тестуємо метод sortByPriceRec
        assertDoesNotThrow(() -> developer.sortByPriceRec(armourList));
    }
    @Test
    void sortByWeightRecTest() {
        Armour armour = new Armour();
        // Створюємо реальний об'єкт розробника з реальними командами
        Developer developer = new Developer(new SortByWeight(armour), new ArmourCatalog(armour), new SortByPrice(armour));

        // Створюємо список обладунків
        LinkedList<Armour> armourList = new LinkedList<>();
        // Додаємо елементи до списку

        // Тестуємо метод sortByWeightRec
        assertDoesNotThrow(() -> developer.sortByWeightRec(armourList));
    }
    @Test
    void armourCatalogRecTest() {
        Armour armour = new Armour();
        // Створюємо реальний об'єкт розробника з реальними командами
        Developer developer = new Developer(new SortByWeight(armour), new ArmourCatalog(armour), new SortByPrice(armour));

        // Тестуємо метод armourCatalogRec
        assertDoesNotThrow(() -> developer.armourCatalogRec());
    }
}