package Menu;

import Equipment.Armour;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class ArmourCatalogTest {
    @Test
    void executeTest(){
        Armour armour = new Armour();
        ArmourCatalog armourCatalog = new ArmourCatalog(armour);
        armourCatalog.execute();
    }
    @Test
    void executeArmTest(){
        LinkedList<Armour> armList = new LinkedList();
        Armour armour = new Armour();
        ArmourCatalog armourCatalog = new ArmourCatalog(armour);
        armourCatalog.executeArmour(armList);
    }

}