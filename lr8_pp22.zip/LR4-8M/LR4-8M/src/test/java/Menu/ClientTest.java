package Menu;

import Equipment.Armour;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {
    @Test
    void testClient(){
        Client client = new Client();
    }
    @Test
    void clientTest() throws IOException {
        Menu menu = new Menu();
        Armour armour = new Armour();
        Developer developer = new Developer(new SortByPrice(armour), new SortByWeight(armour), new ArmourCatalog(armour));
        menu.menu(developer);
    }

}