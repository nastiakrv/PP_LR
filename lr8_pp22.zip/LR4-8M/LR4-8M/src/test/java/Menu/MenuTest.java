package Menu;

import Equipment.Armour;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class MenuTest {
    private Menu begin;
    private Developer developer;
@BeforeEach
public void SetUp(){
    begin = new Menu();
    Armour armour = new Armour();
    Developer developer = new Developer(new SortByPrice(armour), new SortByWeight(armour), new ArmourCatalog(armour));
}
@Test
public void testMenu() throws IOException {
    begin.menu(developer);
}
@Test
    void calcCost(){
    Menu menu = new Menu();
    LinkedList<Armour> armList = new LinkedList<>();
    Armour arm1 = new Armour("Helmet", "helmet", 2.7, 100);
    Armour arm2 = new Armour("Breastplate", "breastplate", 2.7, 100);
    armList.add(arm1);
    armList.add(arm2);
    int total = 0;
    for (Armour armour: armList){
        total += armour.getPrice();
    }
    assertEquals(200, total);
}
@Test
    void menuTest(){
    Menu menu = new Menu();
    ByteArrayInputStream inputStream = new ByteArrayInputStream("3\n".getBytes());
        System.setIn(inputStream);
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
    assertDoesNotThrow(()-> menu.chooseEquip(new Developer()));
    assertTrue(outputStream.toString().contains("You've exited"));
    System.setIn(System.in);
    System.setOut(System.out);
}
@Test
    void chooseEquipTest(){
    Menu menu = new Menu();
    ByteArrayInputStream inputStream = new ByteArrayInputStream("3\n".getBytes());
    System.setIn(inputStream);

}

}




//@Test
//    void menuTest_chooseEquip() throws IOException {
//        // Ми будемо використовувати байтові потоки для введення та виведення
//        ByteArrayInputStream inputStream = new ByteArrayInputStream("1\n".getBytes());
//        System.setIn(inputStream);
//
//        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//        System.setOut(new PrintStream(outputStream));
//
//        // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//
//        // Тестуємо ваш метод
//        assertDoesNotThrow(() -> menuTest.chooseEquip(new Developer()));
//
//        // Перевіряємо виведений результат
//        assertTrue(outputStream.toString().contains("You've exited"));
//
//        // Повертаємо стандартний вивід та введення
//        System.setIn(System.in);
//        System.setOut(System.out);
//    }
//
//    @Test
//    void chooseEquip(Developer developer) throws IOException {
//        // Ми будемо використовувати байтовий потік для введення
//        ByteArrayInputStream inputStream = new ByteArrayInputStream("6\n".getBytes());
//        System.setIn(inputStream);
//
//        // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//
//        // Тестуємо ваш метод
//        assertDoesNotThrow(() -> menuTest.chooseEquip(new Developer()));
//        // Повертаємо стандартний потік введення
//        System.setIn(System.in);
//    }
//
//    @Test
//    void sortMenu(Developer developer, LinkedList<Armour> armourList) throws IOException {
//        // Ми будемо використовувати байтовий потік для введення
//        ByteArrayInputStream inputStream = new ByteArrayInputStream("1\n".getBytes());
//        System.setIn(inputStream);
//
//        // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//
//        // Тестуємо ваш метод
//        assertDoesNotThrow(() -> {
//            //Developer developer = new Developer(); // Чи будь-який об'єкт Developer
//            //LinkedList<Armour> armourList = new LinkedList<>(); // Чи будь-який список armour
//            menuTest.sortMenu(developer, armourList);
//        });
//
//        // Повертаємо стандартний потік введення
//        System.setIn(System.in);
//    }
//
//    @Test
//    LinkedList<Armour> getArmor(int numb) {
//  // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//
//        // Тестуємо ваш метод для кожного випадку вибору
//        for (int i = 1; i <= 5; i++) {
//            LinkedList<Armour> result = menuTest.getArmor(i);
//            assertNotNull(result); // Перевіряємо, чи результат не є null
//            assertFalse(result.isEmpty()); // Перевіряємо, чи результат не є пустим списком
//        }
//        return null;
//    }
//
//    @Test
//    LinkedList<Armour> listsFromFile(String tempFileName, LinkedList llist) {
//        // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//
//        // Створюємо тимчасовий файл для тесту
//        //String tempFileName = "testFile.txt";
//        createTestFile(tempFileName);
//
//        // Тестуємо ваш метод
//        LinkedList<Armour> result = menuTest.listsFromFile(tempFileName, new LinkedList<>());
//
//        // Перевіряємо результат
//        assertNotNull(result);
//        assertFalse(result.isEmpty());
//        assertEquals(2, result.size()); // Припускаємо, що файл містить два рядки
//
//        // Видаляємо тимчасовий файл
//        deleteTestFile(tempFileName);
//        return result;
//    }
//
//    // Допоміжний метод для створення тимчасового файлу для тесту
//    private void createTestFile(String fileName) {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
//            writer.write("Magic helmet, helmet, 2.7, 150\n");
//            writer.write("Transparent helmet, helmet, 3.1, 200\n");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // Допоміжний метод для видалення тимчасового файлу
//    private void deleteTestFile(String fileName) {
//        File file = new File(fileName);
//        if (file.exists()) {
//            file.delete();
//        }
//    }
//    @Test
//    void calculateCostTest_emptyList() {
//        // Створюємо об'єкт вашого класу
//        MenuTest menuTest = new MenuTest();
//        LinkedList<Armour> arm = new LinkedList<>();
//        // Тестуємо ваш метод з пустим списком
//        int result = menuTest.calculateCost(arm);
//
//        // Перевіряємо результат (повинно бути 0, оскільки немає обладунків)
//        assertEquals(0, result);
//    }
//
//    @Test
//    void printArmourList() {
//    }
//
//    @Test
//    void deleteFile() {
//    }