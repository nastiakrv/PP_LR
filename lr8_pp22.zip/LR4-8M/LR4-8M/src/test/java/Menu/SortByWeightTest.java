package Menu;

import Equipment.Armour;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.LinkedList;

import static org.junit.jupiter.api.Assertions.*;

class SortByWeightTest {
    @Test
    void executeTest(){
        Armour armour = new Armour();
        SortByWeight sort = new SortByWeight(armour);
        sort.execute();
    }
    @Test
    void executeArmTest() throws IOException {
        LinkedList<Armour> armList = new LinkedList();
        Armour armour = new Armour();
        SortByWeight sort = new SortByWeight(armour);
        sort.executeArmour(armList);
    }

}